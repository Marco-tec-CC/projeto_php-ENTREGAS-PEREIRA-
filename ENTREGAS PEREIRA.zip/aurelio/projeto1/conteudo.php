<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h2>Custo de entrega:</h2>";
    echo "<img src='https://flamengo.vteximg.com.br/arquivos/ids/166877-1000-1000/taca-1-PhotoRoom.png?v=638174193274430000' height='300px' width='300px'>";
    echo "<h2>Uma taça liberadores</h2>";
