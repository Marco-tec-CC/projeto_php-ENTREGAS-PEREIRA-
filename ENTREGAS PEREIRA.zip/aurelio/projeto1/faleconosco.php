<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php
    echo "<img src='https://i.pinimg.com/736x/b9/6b/4d/b96b4df56442e44765b00781e696bc9e.jpg' height='300px' width='300px'>";
    echo "<p>Este é nosso número:(83) 6662-5151</p>";
