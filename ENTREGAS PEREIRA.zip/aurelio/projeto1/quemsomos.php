<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php
    echo "<h3>Quem somos</h3>";
    echo "<p>Somos da melhor entrega do brasil.</p>";
    echo "<img src='https://i.pinimg.com/736x/b9/6b/4d/b96b4df56442e44765b00781e696bc9e.jpg' width='300px' height='300px'>";
