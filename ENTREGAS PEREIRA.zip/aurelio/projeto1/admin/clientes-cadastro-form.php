<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<div>
    <h2>Cadastro de Cliente</h2>
    <form action="?pg=admin/clientes-cadastro" method="post">
        <label>Nome:</label>
        <input type="text" name="cliente" required><br>
        <label>Cidade:</label>
        <input type="text" name="cidade" required><br>
        <label>Estado:</label>
        <input type="text" name="estado"><br><br>
        <input type="submit" value="Cadastrar">
    </form>
</div>