<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        h3{
            color: blue;
        }
    </style>
</head>
<body>
    <div class="backg">
<?php

    echo "<h1>Entregas Pereira.</h1>";