<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h3>Direitos reservados.</h3>";
?>
</div>
</body>
</html>